﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade_7
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int producao = 0, B = 0, C = 0, D = 0;
            double A, gratificacao, salarioBruto;

            if (double.TryParse(mskbxSalario.Text, out A) && double.TryParse(mskbxGratificacao.Text, out gratificacao)
                && (int.TryParse(txtProducao.Text, out producao)))
            {
                if (producao >= 150)
                    D = 1;
                if (producao <= 149 && producao >= 120)
                    C = 1;
                if (producao <= 119 && producao >= 100)
                    B = 1;

                salarioBruto = A + (A * (0.05 * B + 0.1 * C + 0.1 * D)) + gratificacao;

                if (salarioBruto > 7000)
                    if (D != 1 || gratificacao <= 0)
                        salarioBruto = 7000;

                txtSalarioBruto.Text = salarioBruto.ToString("N2");
            }

            else
                MessageBox.Show("Digite valores válidos!");
        }

    }
}

