﻿
namespace PAtividade_7
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEspaçoemBranco = new System.Windows.Forms.Button();
            this.btnNumeroLetraR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richtxtFrase
            // 
            this.richtxtFrase.Location = new System.Drawing.Point(46, 31);
            this.richtxtFrase.Name = "richtxtFrase";
            this.richtxtFrase.Size = new System.Drawing.Size(705, 134);
            this.richtxtFrase.TabIndex = 0;
            this.richtxtFrase.Text = "";
            // 
            // btnEspaçoemBranco
            // 
            this.btnEspaçoemBranco.Location = new System.Drawing.Point(46, 250);
            this.btnEspaçoemBranco.Name = "btnEspaçoemBranco";
            this.btnEspaçoemBranco.Size = new System.Drawing.Size(126, 73);
            this.btnEspaçoemBranco.TabIndex = 1;
            this.btnEspaçoemBranco.Text = "Espaços em Branco";
            this.btnEspaçoemBranco.UseVisualStyleBackColor = true;
            this.btnEspaçoemBranco.Click += new System.EventHandler(this.btnEspaçoemBranco_Click);
            // 
            // btnNumeroLetraR
            // 
            this.btnNumeroLetraR.Location = new System.Drawing.Point(318, 250);
            this.btnNumeroLetraR.Name = "btnNumeroLetraR";
            this.btnNumeroLetraR.Size = new System.Drawing.Size(126, 73);
            this.btnNumeroLetraR.TabIndex = 2;
            this.btnNumeroLetraR.Text = "Quantidade de letra \'R\'";
            this.btnNumeroLetraR.UseVisualStyleBackColor = true;
            this.btnNumeroLetraR.Click += new System.EventHandler(this.btnNumeroLetraR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.Location = new System.Drawing.Point(625, 250);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(126, 73);
            this.btnParLetras.TabIndex = 3;
            this.btnParLetras.Text = "Par de Letras";
            this.btnParLetras.UseVisualStyleBackColor = true;
            this.btnParLetras.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(696, 387);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(55, 51);
            this.btnClose.TabIndex = 4;
            this.btnClose.Text = "Sair";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(820, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnNumeroLetraR);
            this.Controls.Add(this.btnEspaçoemBranco);
            this.Controls.Add(this.richtxtFrase);
            this.Name = "Form2";
            this.Text = "FormAtividade1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richtxtFrase;
        private System.Windows.Forms.Button btnEspaçoemBranco;
        private System.Windows.Forms.Button btnNumeroLetraR;
        private System.Windows.Forms.Button btnParLetras;
        private System.Windows.Forms.Button btnClose;
    }
}