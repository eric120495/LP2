﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade_7
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }

        private void btnEspaçoemBranco_Click(object sender, EventArgs e)

        { if (richtxtFrase.Text == "")
                MessageBox.Show("Digite o texto!");
          else
           {
               string texto = richtxtFrase.Text.Trim();
           int tamanho = texto.Length;
           int cont = 0;
           int totalEspaco = 0;

                while (cont<tamanho)
                {
                    if (Char.IsWhiteSpace(texto[cont]))
                    {
                       totalEspaco = totalEspaco+1;
                    }
                   cont++;
                }
                MessageBox.Show("Essa Frase tem " + totalEspaco + " espaços em branco!!" );
                
            }
        }
      
        private void btnNumeroLetraR_Click(object sender, EventArgs e)
        {

            if (richtxtFrase.Text == "")
                MessageBox.Show("Digite o texto!");
            else
            {
                string letra = richtxtFrase.Text.Trim();
                int tamnanho = letra.Length;
                int totalR = 0;
                int contador = 0;

                for (contador = 0; contador < tamnanho; contador++)
                {
                    if ((letra[contador] == 'R') || (letra[contador] == 'r'))
                        totalR += 1;
                }
                MessageBox.Show("A quantidade da letra R na frase é: " + totalR);
            }
        }

        private void btnParLetras_Click(object sender, EventArgs e)
        {
            
                if (richtxtFrase.Text == "")
                    MessageBox.Show("Digite o texto!");
                else
                {
                    string texto = richtxtFrase.Text.Trim();
                    int tamanho = texto.Length;
                    int cont = 0;
                    int pares = 0;

                    for (cont = 0; cont < tamanho - 1; cont++)
                    {
                        if (texto[cont] == texto[cont + 1])
                        {
                            pares += 1;
                        }

                       // lblContaPares.Visible = true;
                        //lblContaPares.Text = ocorrenciaPares.ToString("");
                    }
                MessageBox.Show("A quantidade de pares de letras é: " + pares  );            }
            

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
