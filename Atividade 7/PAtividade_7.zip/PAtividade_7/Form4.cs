﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade_7
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text.ToUpper().Replace(" ", "");
            string inverte;

            char[] texto2 = texto.ToCharArray();
            Array.Reverse(texto2);

            inverte = "";
            foreach (char c in texto2)
            {
                inverte = inverte + c.ToString();
            }

            lblInvertido.Visible = true;
            lblInvertido.Text = inverte;

            if (String.Compare(texto, inverte, true) == 0)
            {
                MessageBox.Show("A Frase é palíndromo!!");                
            }
            else
            {
                MessageBox.Show("A Frase não é palíndromo!!");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (txtTexto.TextLength > 50)
            {
                MessageBox.Show("Texto excede 50 caracteres!");

            }
        }
    }
}
    

