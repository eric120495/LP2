﻿
namespace PAtividade_7
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAtividade1 = new System.Windows.Forms.Button();
            this.btnAtividade2 = new System.Windows.Forms.Button();
            this.btnAtividade3 = new System.Windows.Forms.Button();
            this.btnAtividade4 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAtividade1
            // 
            this.btnAtividade1.Location = new System.Drawing.Point(89, 78);
            this.btnAtividade1.Name = "btnAtividade1";
            this.btnAtividade1.Size = new System.Drawing.Size(220, 106);
            this.btnAtividade1.TabIndex = 0;
            this.btnAtividade1.Text = "Atividade 1";
            this.btnAtividade1.UseVisualStyleBackColor = true;
            this.btnAtividade1.Click += new System.EventHandler(this.btnAtividade1_Click);
            // 
            // btnAtividade2
            // 
            this.btnAtividade2.Location = new System.Drawing.Point(486, 78);
            this.btnAtividade2.Name = "btnAtividade2";
            this.btnAtividade2.Size = new System.Drawing.Size(230, 106);
            this.btnAtividade2.TabIndex = 1;
            this.btnAtividade2.Text = "Atividade 2";
            this.btnAtividade2.UseVisualStyleBackColor = true;
            this.btnAtividade2.Click += new System.EventHandler(this.btnAtividade2_Click);
            // 
            // btnAtividade3
            // 
            this.btnAtividade3.Location = new System.Drawing.Point(89, 259);
            this.btnAtividade3.Name = "btnAtividade3";
            this.btnAtividade3.Size = new System.Drawing.Size(220, 101);
            this.btnAtividade3.TabIndex = 2;
            this.btnAtividade3.Text = "Atividade 3";
            this.btnAtividade3.UseVisualStyleBackColor = true;
            this.btnAtividade3.Click += new System.EventHandler(this.btnAtividade3_Click);
            // 
            // btnAtividade4
            // 
            this.btnAtividade4.Location = new System.Drawing.Point(486, 259);
            this.btnAtividade4.Name = "btnAtividade4";
            this.btnAtividade4.Size = new System.Drawing.Size(220, 101);
            this.btnAtividade4.TabIndex = 3;
            this.btnAtividade4.Text = "Atividade 4";
            this.btnAtividade4.UseVisualStyleBackColor = true;
            this.btnAtividade4.Click += new System.EventHandler(this.btnAtividade4_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAtividade4);
            this.Controls.Add(this.btnAtividade3);
            this.Controls.Add(this.btnAtividade2);
            this.Controls.Add(this.btnAtividade1);
            this.Name = "Form1";
            this.Text = "FormPrincipal";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAtividade1;
        private System.Windows.Forms.Button btnAtividade2;
        private System.Windows.Forms.Button btnAtividade3;
        private System.Windows.Forms.Button btnAtividade4;
    }
}

