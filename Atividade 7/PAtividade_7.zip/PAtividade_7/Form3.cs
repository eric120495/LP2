﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade_7
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
           
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        private void btnGerarH_Click(object sender, EventArgs e)
        {
            int N;
            double H, cont;

            H = 1;

            if (int.TryParse(txtNumeroN.Text, out N) && N > 0)
                for (cont = N; cont > 1; cont--)
                {
                    H += (1 / cont);
                }
            else
            {
                MessageBox.Show("Digite um número de N válido");
                H = 0;
            }

            MessageBox.Show("O Número 'H' gerado a partir de 'N' é: " + H.ToString("N2"));
            //lblH.Visible = true;
            //lblH.Text = "O valor de H é: " + H.ToString("N2");

        }
    }
    
}
