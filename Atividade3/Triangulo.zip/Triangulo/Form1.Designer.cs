﻿
namespace Triangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskbxLadoA = new System.Windows.Forms.MaskedTextBox();
            this.MskbxLadoB = new System.Windows.Forms.MaskedTextBox();
            this.MskbxLadoC = new System.Windows.Forms.MaskedTextBox();
            this.labelA = new System.Windows.Forms.Label();
            this.labelB = new System.Windows.Forms.Label();
            this.labelC = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // mskbxLadoA
            // 
            this.mskbxLadoA.Location = new System.Drawing.Point(249, 75);
            this.mskbxLadoA.Margin = new System.Windows.Forms.Padding(4);
            this.mskbxLadoA.Name = "mskbxLadoA";
            this.mskbxLadoA.Size = new System.Drawing.Size(132, 22);
            this.mskbxLadoA.TabIndex = 0;
            this.mskbxLadoA.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // MskbxLadoB
            // 
            this.MskbxLadoB.Location = new System.Drawing.Point(249, 154);
            this.MskbxLadoB.Margin = new System.Windows.Forms.Padding(4);
            this.MskbxLadoB.Name = "MskbxLadoB";
            this.MskbxLadoB.Size = new System.Drawing.Size(132, 22);
            this.MskbxLadoB.TabIndex = 1;
            this.MskbxLadoB.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox2_MaskInputRejected);
            // 
            // MskbxLadoC
            // 
            this.MskbxLadoC.Location = new System.Drawing.Point(249, 250);
            this.MskbxLadoC.Margin = new System.Windows.Forms.Padding(4);
            this.MskbxLadoC.Name = "MskbxLadoC";
            this.MskbxLadoC.Size = new System.Drawing.Size(132, 22);
            this.MskbxLadoC.TabIndex = 2;
            // 
            // labelA
            // 
            this.labelA.AutoSize = true;
            this.labelA.Location = new System.Drawing.Point(72, 75);
            this.labelA.Name = "labelA";
            this.labelA.Size = new System.Drawing.Size(17, 16);
            this.labelA.TabIndex = 3;
            this.labelA.Text = "A";
            // 
            // labelB
            // 
            this.labelB.AutoSize = true;
            this.labelB.Location = new System.Drawing.Point(72, 160);
            this.labelB.Name = "labelB";
            this.labelB.Size = new System.Drawing.Size(17, 16);
            this.labelB.TabIndex = 4;
            this.labelB.Text = "B";
            // 
            // labelC
            // 
            this.labelC.AutoSize = true;
            this.labelC.Location = new System.Drawing.Point(72, 250);
            this.labelC.Name = "labelC";
            this.labelC.Size = new System.Drawing.Size(17, 16);
            this.labelC.TabIndex = 5;
            this.labelC.Text = "C";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(140, 366);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(132, 60);
            this.btnVerificar.TabIndex = 6;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.labelC);
            this.Controls.Add(this.labelB);
            this.Controls.Add(this.labelA);
            this.Controls.Add(this.MskbxLadoC);
            this.Controls.Add(this.MskbxLadoB);
            this.Controls.Add(this.mskbxLadoA);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "triangulo";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskbxLadoA;
        private System.Windows.Forms.MaskedTextBox MskbxLadoB;
        private System.Windows.Forms.MaskedTextBox MskbxLadoC;
        private System.Windows.Forms.Label labelA;
        private System.Windows.Forms.Label labelB;
        private System.Windows.Forms.Label labelC;
        private System.Windows.Forms.Button btnVerificar;
    }
}

