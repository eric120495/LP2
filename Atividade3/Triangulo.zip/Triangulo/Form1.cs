﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        int LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox4_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(mskbxLadoA.Text, out LadoA) &&
                int.TryParse(MskbxLadoB.Text, out LadoB) &&
                int.TryParse(MskbxLadoC.Text, out LadoC));
            else
                MessageBox.Show("Valor invalido!!");

            if (Math.Abs(LadoB - LadoC) < LadoA && LadoA < (LadoB + LadoC) &&
                Math.Abs(LadoA - LadoC) < LadoB && LadoB < (LadoA + LadoC) &&
                Math.Abs(LadoA - LadoB) < LadoC && LadoC < (LadoA + LadoB));
            {
                if (LadoA == LadoB && LadoB==LadoC)
                    MessageBox.Show("Triangulo Equilatero!!");
                else
                    if(LadoA == LadoB || LadoA == LadoC || LadoB == LadoC)
                       MessageBox.Show("Triangulo Isosceles!!");
                    else
                    MessageBox.Show("Triangulo Escaleno!!");

            }
        }
    }
}
