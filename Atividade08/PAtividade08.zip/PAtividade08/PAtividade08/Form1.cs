﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade08
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Entre com o número de posição: " + (i + 1), "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }


            }

            auxiliar = "";

            for (var i = vetor.Length - 1; i >= 0; i--)
                auxiliar += "\n" + vetor[i];

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string lstCompleta = "";

            for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox("Entre com o número de posição: " + (i + 1), "Entrada de Dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);

            foreach (int c in vetor)
            {
                lstCompleta = lstCompleta + " " + c;

            }

            MessageBox.Show(lstCompleta.ToString());
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            int[] quantia = new int[10];
            double[] preco = new double[10];
            double fatMensal = 0;

            string auxiliar = "";

            for (var i = 0; i < quantia.Length; i++)
            {
                while (quantia[i] <= 0)
                {
                    auxiliar = Interaction.InputBox("Entre com a quantidade: " + (i + 1), "Entrada de Dados");
                    if (!int.TryParse(auxiliar, out quantia[i]))
                    {
                        MessageBox.Show("Quantidade inválida");
                    }
                }

                while (preco[i] <= 0)
                {
                    auxiliar = Interaction.InputBox("Entre com o preço: " + (i + 1), "Entrada de Dados");

                    if (!double.TryParse(auxiliar, out preco[i]))
                    {
                        MessageBox.Show("Preço inválido");
                    }
                }

                fatMensal = fatMensal + (quantia[i] * preco[i]);

            }

            MessageBox.Show("O faturamento mensal é: " + fatMensal.ToString());
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {

            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };

            Int32 I, Total = 0;

            Int32 N = Alunos.Length;

            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }

            MessageBox.Show(Total.ToString());
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {

            List<string> lista = new List<string>(new string[] { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" });
            string listaCompleta = "";

            lista.RemoveAt(6);

            foreach (string nome in lista)
            {
                listaCompleta = listaCompleta + " " + nome;

            }
            MessageBox.Show(listaCompleta);
        }

        private void btnExercicio6_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            string resultado = "";
            double[] media = new double[20];

            for (var i = 0; i < notas.GetLength(0); i++)
            {
                for (var j = 0; j < notas.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox("Entre com a nota " + (j + 1) + " do aluno " + (i + 1), "Entrada de Dados");
                    if (!double.TryParse(auxiliar, out notas[i, j]))
                    {
                        MessageBox.Show("Nota inválida!");
                        j--;
                    }
                    else
                    {
                        if (notas[i, j] >= 0 && notas[i, j] <= 10)
                            media[i] = (media[i] + notas[i, j]);
                        else
                        {
                            MessageBox.Show("Nota inválida: deve estar entre 0 e 10");
                            j--;
                        }
                    }
                }
            }


            for (var i = 0; i < 20; i++)
            {
               media[i] = Math.Round((media[i] / 3), 2);
               resultado = resultado + "Aluno " + (i + 1) + " : média " + media[i] + "\n";

            }

                MessageBox.Show(resultado.ToString());
                
            
        }

        private void btnExercicio7_Click(object sender, EventArgs e)
        {
            string[] nome = new string[1];
            string auxiliar = "";
            int[] qtde = new int[1];
            string[] resultado = new string[1];

            for (var i = 0; i < nome.Length; i++)
            {
                auxiliar = Interaction.InputBox("Entre com o nome: " + (i + 1), "Entrada de Dados");
                nome[i] = auxiliar;
                auxiliar = auxiliar.Replace(" ", "");
                qtde[i] = (auxiliar.Length);

                resultado[i] = "O nome: " + nome[i] + " tem " + qtde[i] + " caracteres ";

                lstbxListaNomes.Items.Add(resultado[i]);
            }
        }
    }
}
