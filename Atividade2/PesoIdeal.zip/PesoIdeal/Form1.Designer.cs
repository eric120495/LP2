﻿
namespace PesoIdeal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAltura = new System.Windows.Forms.Label();
            this.txtPesoAtual = new System.Windows.Forms.Label();
            this.txtPesoIdeal = new System.Windows.Forms.Label();
            this.RbtnM = new System.Windows.Forms.RadioButton();
            this.RbtnF = new System.Windows.Forms.RadioButton();
            this.BtnCalc = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtAlt = new System.Windows.Forms.MaskedTextBox();
            this.txtPesoAt = new System.Windows.Forms.MaskedTextBox();
            this.txtPesoId = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAltura
            // 
            this.txtAltura.AutoSize = true;
            this.txtAltura.Location = new System.Drawing.Point(44, 28);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(51, 20);
            this.txtAltura.TabIndex = 0;
            this.txtAltura.Text = "Altura";
            // 
            // txtPesoAtual
            // 
            this.txtPesoAtual.AutoSize = true;
            this.txtPesoAtual.Location = new System.Drawing.Point(40, 236);
            this.txtPesoAtual.Name = "txtPesoAtual";
            this.txtPesoAtual.Size = new System.Drawing.Size(86, 20);
            this.txtPesoAtual.TabIndex = 2;
            this.txtPesoAtual.Text = "Peso Atual";
            // 
            // txtPesoIdeal
            // 
            this.txtPesoIdeal.AutoSize = true;
            this.txtPesoIdeal.Location = new System.Drawing.Point(44, 362);
            this.txtPesoIdeal.Name = "txtPesoIdeal";
            this.txtPesoIdeal.Size = new System.Drawing.Size(84, 20);
            this.txtPesoIdeal.TabIndex = 3;
            this.txtPesoIdeal.Text = "Peso Ideal";
            // 
            // RbtnM
            // 
            this.RbtnM.AutoSize = true;
            this.RbtnM.Checked = true;
            this.RbtnM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbtnM.Location = new System.Drawing.Point(33, 40);
            this.RbtnM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RbtnM.Name = "RbtnM";
            this.RbtnM.Size = new System.Drawing.Size(38, 20);
            this.RbtnM.TabIndex = 7;
            this.RbtnM.TabStop = true;
            this.RbtnM.Text = "M";
            this.RbtnM.UseVisualStyleBackColor = true;
            // 
            // RbtnF
            // 
            this.RbtnF.AutoSize = true;
            this.RbtnF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RbtnF.Location = new System.Drawing.Point(151, 40);
            this.RbtnF.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RbtnF.Name = "RbtnF";
            this.RbtnF.Size = new System.Drawing.Size(35, 20);
            this.RbtnF.TabIndex = 8;
            this.RbtnF.TabStop = true;
            this.RbtnF.Text = "F";
            this.RbtnF.UseVisualStyleBackColor = true;
            this.RbtnF.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // BtnCalc
            // 
            this.BtnCalc.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCalc.Location = new System.Drawing.Point(359, 447);
            this.BtnCalc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnCalc.Name = "BtnCalc";
            this.BtnCalc.Size = new System.Drawing.Size(154, 60);
            this.BtnCalc.TabIndex = 9;
            this.BtnCalc.Text = "Calcular";
            this.BtnCalc.UseVisualStyleBackColor = true;
            this.BtnCalc.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RbtnF);
            this.groupBox1.Controls.Add(this.RbtnM);
            this.groupBox1.Location = new System.Drawing.Point(266, 93);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(247, 88);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // txtAlt
            // 
            this.txtAlt.Location = new System.Drawing.Point(266, 22);
            this.txtAlt.Mask = "0.00";
            this.txtAlt.Name = "txtAlt";
            this.txtAlt.Size = new System.Drawing.Size(100, 26);
            this.txtAlt.TabIndex = 12;
            this.txtAlt.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextBox1_MaskInputRejected);
            // 
            // txtPesoAt
            // 
            this.txtPesoAt.Location = new System.Drawing.Point(266, 236);
            this.txtPesoAt.Mask = "00.0";
            this.txtPesoAt.Name = "txtPesoAt";
            this.txtPesoAt.Size = new System.Drawing.Size(100, 26);
            this.txtPesoAt.TabIndex = 13;
            // 
            // txtPesoId
            // 
            this.txtPesoId.Enabled = false;
            this.txtPesoId.Location = new System.Drawing.Point(266, 362);
            this.txtPesoId.Mask = "00.0";
            this.txtPesoId.Name = "txtPesoId";
            this.txtPesoId.Size = new System.Drawing.Size(100, 26);
            this.txtPesoId.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "Sexo";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPesoId);
            this.Controls.Add(this.txtPesoAt);
            this.Controls.Add(this.txtAlt);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BtnCalc);
            this.Controls.Add(this.txtPesoIdeal);
            this.Controls.Add(this.txtPesoAtual);
            this.Controls.Add(this.txtAltura);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "PesoIdeal";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtAltura;
        private System.Windows.Forms.Label txtPesoAtual;
        private System.Windows.Forms.Label txtPesoIdeal;
        private System.Windows.Forms.RadioButton RbtnM;
        private System.Windows.Forms.RadioButton RbtnF;
        private System.Windows.Forms.Button BtnCalc;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MaskedTextBox txtAlt;
        private System.Windows.Forms.MaskedTextBox txtPesoAt;
        private System.Windows.Forms.MaskedTextBox txtPesoId;
        private System.Windows.Forms.Label label1;
    }
}

