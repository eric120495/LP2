﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form

    {
        double Altura, PesoAtual, PesoIdeal;
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtAlt.Text, out Altura) &&
                double.TryParse(txtPesoAt.Text, out PesoAtual))
                
            {
                if (RbtnM.Checked)
                    PesoIdeal = (72.7 * Altura) - 58;
                else
                    PesoIdeal = (62.1 * Altura) - 44.7;
                txtPesoId.Text = PesoIdeal.ToString();

                if (PesoAtual > PesoIdeal)
                    MessageBox.Show("Regime recomendado!!");
                else
                    if (PesoAtual < PesoIdeal)
                        MessageBox.Show("Recomendado comer bem!!");
                    else
                        MessageBox.Show("Seu Peso é o Ideal!!");
            }
            else
                MessageBox.Show("Altura ou Peso Inválido!!");
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
