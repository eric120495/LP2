﻿
namespace SalárioFunc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNomeFunc = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblAliInss = new System.Windows.Forms.Label();
            this.lblAliIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLíquido = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.btnCalcDesc = new System.Windows.Forms.Button();
            this.txtNomeFunc = new System.Windows.Forms.TextBox();
            this.mskbxSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.txtAliINSS = new System.Windows.Forms.TextBox();
            this.txtAliIRPF = new System.Windows.Forms.TextBox();
            this.txtSalFamilia = new System.Windows.Forms.TextBox();
            this.txtSalLiquido = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.ckbxEstadoCivil = new System.Windows.Forms.CheckBox();
            this.lblDados = new System.Windows.Forms.Label();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.cbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.gbxSexo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNomeFunc
            // 
            this.lblNomeFunc.AutoSize = true;
            this.lblNomeFunc.Location = new System.Drawing.Point(59, 46);
            this.lblNomeFunc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNomeFunc.Name = "lblNomeFunc";
            this.lblNomeFunc.Size = new System.Drawing.Size(118, 16);
            this.lblNomeFunc.TabIndex = 0;
            this.lblNomeFunc.Text = "Nome Funcionario";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.Location = new System.Drawing.Point(59, 96);
            this.lblSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(85, 16);
            this.lblSalarioBruto.TabIndex = 1;
            this.lblSalarioBruto.Text = "Salário Bruto";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(59, 150);
            this.lblNumFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(114, 16);
            this.lblNumFilhos.TabIndex = 2;
            this.lblNumFilhos.Text = "Número de Filhos";
            // 
            // lblAliInss
            // 
            this.lblAliInss.AutoSize = true;
            this.lblAliInss.Location = new System.Drawing.Point(59, 271);
            this.lblAliInss.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliInss.Name = "lblAliInss";
            this.lblAliInss.Size = new System.Drawing.Size(91, 16);
            this.lblAliInss.TabIndex = 3;
            this.lblAliInss.Text = "Alíquota INSS";
            // 
            // lblAliIRPF
            // 
            this.lblAliIRPF.AutoSize = true;
            this.lblAliIRPF.Location = new System.Drawing.Point(59, 343);
            this.lblAliIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliIRPF.Name = "lblAliIRPF";
            this.lblAliIRPF.Size = new System.Drawing.Size(90, 16);
            this.lblAliIRPF.TabIndex = 4;
            this.lblAliIRPF.Text = "Alíquota IRPF";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(59, 403);
            this.lblSalFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(98, 16);
            this.lblSalFamilia.TabIndex = 5;
            this.lblSalFamilia.Text = "Salário Família";
            this.lblSalFamilia.Click += new System.EventHandler(this.label6_Click);
            // 
            // lblSalLíquido
            // 
            this.lblSalLíquido.AutoSize = true;
            this.lblSalLíquido.Location = new System.Drawing.Point(59, 468);
            this.lblSalLíquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalLíquido.Name = "lblSalLíquido";
            this.lblSalLíquido.Size = new System.Drawing.Size(98, 16);
            this.lblSalLíquido.TabIndex = 6;
            this.lblSalLíquido.Text = "Salário Líquido";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(569, 271);
            this.lblDescINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(100, 16);
            this.lblDescINSS.TabIndex = 7;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(569, 329);
            this.lblDescIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(99, 16);
            this.lblDescIRPF.TabIndex = 8;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // btnCalcDesc
            // 
            this.btnCalcDesc.Location = new System.Drawing.Point(572, 434);
            this.btnCalcDesc.Name = "btnCalcDesc";
            this.btnCalcDesc.Size = new System.Drawing.Size(162, 50);
            this.btnCalcDesc.TabIndex = 9;
            this.btnCalcDesc.Text = "Calcular Desconto";
            this.btnCalcDesc.UseVisualStyleBackColor = true;
            this.btnCalcDesc.Click += new System.EventHandler(this.BtnCalcDesc_Click);
            // 
            // txtNomeFunc
            // 
            this.txtNomeFunc.Location = new System.Drawing.Point(221, 41);
            this.txtNomeFunc.Name = "txtNomeFunc";
            this.txtNomeFunc.Size = new System.Drawing.Size(196, 22);
            this.txtNomeFunc.TabIndex = 10;
            // 
            // mskbxSalarioBruto
            // 
            this.mskbxSalarioBruto.Location = new System.Drawing.Point(221, 90);
            this.mskbxSalarioBruto.Mask = "000000.00";
            this.mskbxSalarioBruto.Name = "mskbxSalarioBruto";
            this.mskbxSalarioBruto.Size = new System.Drawing.Size(196, 22);
            this.mskbxSalarioBruto.TabIndex = 11;
            // 
            // txtAliINSS
            // 
            this.txtAliINSS.Enabled = false;
            this.txtAliINSS.Location = new System.Drawing.Point(221, 271);
            this.txtAliINSS.Name = "txtAliINSS";
            this.txtAliINSS.Size = new System.Drawing.Size(196, 22);
            this.txtAliINSS.TabIndex = 13;
            // 
            // txtAliIRPF
            // 
            this.txtAliIRPF.Enabled = false;
            this.txtAliIRPF.Location = new System.Drawing.Point(221, 340);
            this.txtAliIRPF.Name = "txtAliIRPF";
            this.txtAliIRPF.Size = new System.Drawing.Size(196, 22);
            this.txtAliIRPF.TabIndex = 14;
            // 
            // txtSalFamilia
            // 
            this.txtSalFamilia.Enabled = false;
            this.txtSalFamilia.Location = new System.Drawing.Point(221, 403);
            this.txtSalFamilia.Name = "txtSalFamilia";
            this.txtSalFamilia.Size = new System.Drawing.Size(196, 22);
            this.txtSalFamilia.TabIndex = 15;
            // 
            // txtSalLiquido
            // 
            this.txtSalLiquido.Enabled = false;
            this.txtSalLiquido.Location = new System.Drawing.Point(221, 468);
            this.txtSalLiquido.Name = "txtSalLiquido";
            this.txtSalLiquido.Size = new System.Drawing.Size(196, 22);
            this.txtSalLiquido.TabIndex = 16;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Location = new System.Drawing.Point(738, 271);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(196, 22);
            this.txtDescINSS.TabIndex = 17;
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Location = new System.Drawing.Point(738, 323);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(196, 22);
            this.txtDescIRPF.TabIndex = 18;
            // 
            // ckbxEstadoCivil
            // 
            this.ckbxEstadoCivil.AutoSize = true;
            this.ckbxEstadoCivil.Location = new System.Drawing.Point(572, 178);
            this.ckbxEstadoCivil.Name = "ckbxEstadoCivil";
            this.ckbxEstadoCivil.Size = new System.Drawing.Size(75, 20);
            this.ckbxEstadoCivil.TabIndex = 19;
            this.ckbxEstadoCivil.Text = "Casado";
            this.ckbxEstadoCivil.UseVisualStyleBackColor = true;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(62, 209);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(49, 16);
            this.lblDados.TabIndex = 20;
            this.lblDados.Text = "Dados";
            this.lblDados.Visible = false;
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Checked = true;
            this.rbtnMasculino.Location = new System.Drawing.Point(23, 41);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(37, 20);
            this.rbtnMasculino.TabIndex = 21;
            this.rbtnMasculino.TabStop = true;
            this.rbtnMasculino.Text = "M";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.Location = new System.Drawing.Point(135, 41);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(34, 20);
            this.rbtnFeminino.TabIndex = 22;
            this.rbtnFeminino.Text = "F";
            this.rbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbtnMasculino);
            this.gbxSexo.Controls.Add(this.rbtnFeminino);
            this.gbxSexo.Location = new System.Drawing.Point(572, 41);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Size = new System.Drawing.Size(200, 100);
            this.gbxSexo.TabIndex = 23;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // cbxNumFilhos
            // 
            this.cbxNumFilhos.FormattingEnabled = true;
            this.cbxNumFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.cbxNumFilhos.Location = new System.Drawing.Point(221, 150);
            this.cbxNumFilhos.Name = "cbxNumFilhos";
            this.cbxNumFilhos.Size = new System.Drawing.Size(196, 24);
            this.cbxNumFilhos.Sorted = true;
            this.cbxNumFilhos.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.cbxNumFilhos);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.ckbxEstadoCivil);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtSalLiquido);
            this.Controls.Add(this.txtSalFamilia);
            this.Controls.Add(this.txtAliIRPF);
            this.Controls.Add(this.txtAliINSS);
            this.Controls.Add(this.mskbxSalarioBruto);
            this.Controls.Add(this.txtNomeFunc);
            this.Controls.Add(this.btnCalcDesc);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLíquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblAliIRPF);
            this.Controls.Add(this.lblAliInss);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNomeFunc);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeFunc;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblAliInss;
        private System.Windows.Forms.Label lblAliIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLíquido;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Button btnCalcDesc;
        private System.Windows.Forms.TextBox txtNomeFunc;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioBruto;
        private System.Windows.Forms.TextBox txtAliINSS;
        private System.Windows.Forms.TextBox txtAliIRPF;
        private System.Windows.Forms.TextBox txtSalFamilia;
        private System.Windows.Forms.TextBox txtSalLiquido;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.CheckBox ckbxEstadoCivil;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.ComboBox cbxNumFilhos;
    }
}

