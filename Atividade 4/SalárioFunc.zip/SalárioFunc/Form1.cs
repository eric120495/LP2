﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalárioFunc
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnCalcDesc_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;

            double descontoINSS = 0;
            double descontoIRPF = 0;
            double SalarioFamilia = 0;
            double salarioBruto = 0;
            double SalarioLiquido = 0;


            if ((txtNomeFunc.Text == "") || (txtNomeFunc.Text.Length < 5))
                MessageBox.Show("Nome Inválido!");
            if (double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
            {
                // Cálculo desconto INSS
                if (salarioBruto <= 800.47)
                {
                    txtAliINSS.Text = "7.65%";
                    descontoINSS = 0.0765 * salarioBruto;
                }

                else if (salarioBruto <= 1050)
                {

                    txtAliINSS.Text = "8.65%";
                    descontoINSS = 0.0865 * salarioBruto;
                }
                else if (salarioBruto <= 1400.77)
                {
                    txtAliINSS.Text = "9%";
                    descontoINSS = 0.09 * salarioBruto;
                }
                else if (salarioBruto <= 2801.56)
                {
                    txtAliINSS.Text = "11%";
                    descontoINSS = 0.11 * salarioBruto;

                }
                else if (salarioBruto > 2801.56)
                {
                    txtAliINSS.Text = "teto";
                    descontoINSS = 308.17;

                }
                descontoINSS = Math.Round(descontoINSS, 2);
                txtDescINSS.Text = descontoINSS.ToString("N2");

                //Calculo desconto IRPF
                if (salarioBruto <= 1257.12)
                {
                    txtAliIRPF.Text = "Isento";
                    descontoIRPF = 0;
                }
                else if (salarioBruto <= 2512.08)
                {
                    txtAliIRPF.Text = "15%";
                    descontoIRPF = 0.15 * salarioBruto;
                }
                else if (salarioBruto > 2512.08)
                {
                    txtAliIRPF.Text = "27.5%";
                    descontoIRPF = 0.275 * salarioBruto;
                }
                descontoIRPF = Math.Round(descontoIRPF, 2);
                txtDescIRPF.Text = descontoIRPF.ToString("N2");

                if (salarioBruto <= 435.52)
                {
                    SalarioFamilia = 22.33 * (cbxNumFilhos.SelectedIndex);
                }
                else if (salarioBruto <= 654.61)
                    SalarioFamilia = 15.74 * (cbxNumFilhos.SelectedIndex);
                else if (salarioBruto > 654.61)
                {
                    SalarioFamilia = 0;
                }
                SalarioFamilia = Math.Round(SalarioFamilia, 2);
                txtSalFamilia.Text = SalarioFamilia.ToString("N2");

                SalarioLiquido = salarioBruto - descontoINSS - descontoIRPF + SalarioFamilia;
                SalarioLiquido = Math.Round(SalarioLiquido, 2);
                txtSalLiquido.Text = SalarioLiquido.ToString("N2");

                lblDados.Text = "Os descontos do salário ";

                if (rbtnFeminino.Checked)
                    lblDados.Text = lblDados.Text + " da Sra. " + txtNomeFunc.Text;
                else
                    lblDados.Text = lblDados.Text + " do Sr. " + txtNomeFunc.Text;

                lblDados.Text = lblDados.Text + " que é";

                if (ckbxEstadoCivil.Checked)
                    lblDados.Text = lblDados.Text + " casado(a) ";
                else
                    lblDados.Text = lblDados.Text + " solteiro(a) ";

                lblDados.Text = lblDados.Text + " e que tem " + (cbxNumFilhos.SelectedIndex) + " Filho(s) são: ";
            }

            else
                MessageBox.Show("Salário Inválido!");
        }
    }
}
