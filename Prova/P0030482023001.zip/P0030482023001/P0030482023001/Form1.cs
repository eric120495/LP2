﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace P0030482023001
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] planilhaVendas = new double[1, 4];
            double[] totalVendidoMes = new double[1];
            double[] totalVendidoSemana = new double[4];
            string valor;
            double totalGeral = 0;


            for (int i = 0; i < 1; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    valor = Interaction.InputBox("Digite o valor da semana " + (j    + 1) + " Do Mês: " + (i + 1), "Entrada de dados");
                    if (valor == "")
                    {
                        MessageBox.Show("Valor inserido inválido!!!");
                        j--;
                    }
                    else if (double.TryParse(valor, out totalVendidoSemana[j]))
                    {
                        double.TryParse(valor, out totalVendidoSemana[j]);
                    }
                    else
                    {
                        MessageBox.Show("Digite apenas números!!!");
                        j--;
                    }
                }
            }


            for (int i = 0; i < 1; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    totalVendidoMes[i] = totalVendidoMes[i] + totalVendidoSemana[j];
                }
                totalGeral = totalGeral + totalVendidoMes[i];
            }

            for (int i = 0; i < 1; i++)
            {
                for (int j = 0; j < 4; j++)
                {

                    lstbxPlanilha.Items.Add("Total do Mês: " + (i + 1) + " Semana: " + (j + 1) + String.Format("{0:C2}", totalVendidoSemana[j]));
                }

                lstbxPlanilha.Items.Add("Total Mês: " + totalVendidoMes[i]  + String.Format("{0:C2}", totalVendidoMes[i]));
               
            }
            lstbxPlanilha.Items.Add("Total Geral: " + String.Format("{0:C2}", totalGeral));
        }
            
        
    }
}
